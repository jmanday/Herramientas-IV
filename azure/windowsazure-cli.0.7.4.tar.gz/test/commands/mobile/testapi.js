exports.get = function (req, res) {
  return 'Hello, world!';
};