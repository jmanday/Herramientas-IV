function foobar() {
    console.log('Sample information');
}