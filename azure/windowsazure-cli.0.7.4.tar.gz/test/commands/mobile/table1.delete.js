function del(item, user, request) {
    console.log('Sample information');
    console.error('Sample error');
    request.execute();
}